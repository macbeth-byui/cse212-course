﻿/*
 * CSE 212 Lesson 6C 
 * 
 * This code will analyze the NBA basketball data and create a table showing
 * the players with the top 10 career points.
 * 
 * Note about columns:
 * - Player ID is in column 0
 * - Points is in column 8
 * 
 * Each row represents the player's stats for a single season with a single team.
 */

using Microsoft.VisualBasic.FileIO;

var players = new Dictionary<string, int>();
var names = new Dictionary<string, string>();

using var reader = new TextFieldParser("basketball.csv");
reader.TextFieldType = FieldType.Delimited;
reader.SetDelimiters(",");
reader.ReadFields(); // ignore header row
while (!reader.EndOfData) {
    var fields = reader.ReadFields()!;
    var playerId = fields[1];
    var playerName = fields[3];
    var points = int.Parse(fields[25]);
    if (players.ContainsKey(playerId))
        players[playerId] += points;
    else
        players[playerId] = points;
    names[playerId] = playerName;
}

// Console.WriteLine($"Players: {{{string.Join(", ", players)}}}");

var topPlayers = players.ToArray();
Array.Sort(topPlayers, (p1, p2) => p2.Value - p1.Value);

Console.WriteLine();
for (var i = 0; i < 10; ++i) {
    Console.WriteLine(names[topPlayers[i].Key] + ": " + topPlayers[i].Value);
}
